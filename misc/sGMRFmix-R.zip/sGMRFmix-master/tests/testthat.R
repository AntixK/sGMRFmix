library(testthat)
library(sGMRFmix)

test_check("sGMRFmix")
