# sGMRFmix 0.3.0

## Improvements

- Improve mode estimation

# sGMRFmix 0.2.0

## New features

- Add k-means initializetion

## Improvements

- Automatically `scale` input (#2).
- Refine `plot_multivariate_data`

## Bug fixes

- Allow to input `tibble` (#1).
